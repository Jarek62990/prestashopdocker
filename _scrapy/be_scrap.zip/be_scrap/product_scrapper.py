from bs4 import BeautifulSoup

import constants as constants


class ProductHtmlElementsGetter:
    def __init__(self, rawProductHtml):
        self.rawProductHtml = rawProductHtml

    def getMainAnchorElement(self):
        return self.rawProductHtml.find('a', attrs = {'class': 'product__icon'})

    def getProductSizeElements(self):
        return self.rawProductHtml.findAll('span', attrs = {'class': 'product__size'})

    def getOldPriceElement(self):
        return self.rawProductHtml.find('del', attrs = {'class': 'price --max'})

    def getNewPriceElement(self):
        return self.rawProductHtml.find('strong', attrs = {'class': 'price'})

    def getProductNameElement(self):
        return self.rawProductHtml.find('a', attrs = {'class': 'product__name'})

    def getImageElement(self):
        return self.getMainAnchorElement().find('img')


class ProductScrapper:
    def __init__(self, rawProductHtml):
        self.productElementsGetter = ProductHtmlElementsGetter(rawProductHtml)

    def extractImageUrl(self):
        imageElement = self.productElementsGetter.getImageElement()
        return constants.DOMAIN + imageElement['src']

    def extractProductUrl(self):
        anchorElement = self.productElementsGetter.getMainAnchorElement()
        return anchorElement['href']

    def extractProductSizes(self):
        sizes = []
        for productSizeElement in self.productElementsGetter.getProductSizeElements():
            size = productSizeElement.contents[0]
            sizes.append(size)
        return sizes

    def extractProductOldPrice(self):
        oldPriceElement = self.productElementsGetter.getOldPriceElement()
        return None if oldPriceElement == None else oldPriceElement.contents[0]

    def extractProductNewPrice(self):
        newPriceElement = self.productElementsGetter.getNewPriceElement()
        return None if newPriceElement == None else newPriceElement.contents[0]

    def extractProductName(self):
        productNameElement = self.productElementsGetter.getProductNameElement()
        return productNameElement.contents[0]