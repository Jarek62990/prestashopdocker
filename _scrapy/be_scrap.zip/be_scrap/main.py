import json

import constants as constants
from product_scrapper import ProductScrapper
from page_fetcher import getWholePageContent


def getProcessedProduct(productScrapper):
    processedProduct = {}
    processedProduct['name'] = productScrapper.extractProductName()
    processedProduct['oldPrice'] = productScrapper.extractProductOldPrice()
    processedProduct['newPrice'] = productScrapper.extractProductNewPrice()
    processedProduct['sizes'] = productScrapper.extractProductSizes()
    processedProduct['imageUrl'] = productScrapper.extractImageUrl()
    processedProduct['productUrl'] = productScrapper.extractProductUrl()
    return processedProduct


def getProcessedProducts(productsList):
    processedProducts = []
    for rawProduct in productsList:
        productScrapper = ProductScrapper(rawProduct)
        processedProduct = getProcessedProduct(productScrapper)
        processedProducts.append(processedProduct)
    return processedProducts


def getProductsSection(pageContent):
    return pageContent.find('section', attrs = {'id': 'search'})


def getProductsList(pageContent):
    productsSection = getProductsSection(pageContent)
    return productsSection.findAll('div', attrs = {'class': 'product'})


def createCategoryDictionary(category_url, processedProducts):
    dictionary = {}
    dictionary['category'] = category_url
    dictionary['processedProducts'] = processedProducts
    return dictionary

    
def scrapCategory(category_url):
    pageContent = getWholePageContent(category_url)
    productsList = getProductsList(pageContent)
    processedProducts = getProcessedProducts(productsList)
    return createCategoryDictionary(category_url, processedProducts)


def scrapData():
    scrappedCategories = []

    for category_url in constants.CATEGORIES_URL:
        categoryDictionary = scrapCategory(constants.DOMAIN + category_url)
        scrappedCategories.append(categoryDictionary)
    
    return scrappedCategories


def getProductDescriptionListElement(productPage):
    productDescriptionSectionWrapper = productPage.find('section', attrs = {'class': 'product_name__description'})
    return productDescriptionSectionWrapper.find('ul').find('li') if productDescriptionSectionWrapper else None


def getProductDescription(productPage):
    productDescriptionListElement = getProductDescriptionListElement(productPage)
    return productDescriptionListElement.contents[0] if productDescriptionListElement else "Brak Opisu"


def scrapProductDescription(scrappedProduct):
    productPage = getWholePageContent(url=scrappedProduct['productUrl'], withSlowlyScrollingToEnd=False)
    scrappedProduct['productDescription'] = getProductDescription(productPage)
    print(scrappedProduct['productDescription'])


def scrapEachProductDescriptionInScrappedCategory(scrappedCategory):
    for scrappedProduct in scrappedCategory['processedProducts']:
        scrapProductDescription(scrappedProduct)


def scrapEachProductDescriptionInScrappedData(scrappedData):
    for scrappedCategory in scrappedData:
        scrapEachProductDescriptionInScrappedCategory(scrappedCategory)


def printScrappedData(scrappedData):
    for scrappedCategory in scrappedData:
        print(json.dumps(scrappedCategory, indent=4, sort_keys=True))


def writeScrappedDataToJson(scrappedData):
    with open("json_data.json", "w", encoding='utf-8') as f:
        json.dump(scrappedData, f, ensure_ascii=False)


scrappedData = scrapData()
scrapEachProductDescriptionInScrappedData(scrappedData)
writeScrappedDataToJson(scrappedData)