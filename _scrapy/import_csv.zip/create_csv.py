import json
import csv
import re
import enum

class Product :
    aktywny = 1
    isPodatek = 1
    regulaPodatku = 5
    wSprzedazy = 1
    pathImg = 'http://wieczynska.pl/zdjecia/'

class Atribut :
    nazwa = 'Rozmiar:'
    typ = 'select'
    pozycja = ':0'

ilosc = 50

def wytnijUrl(url) :
    return url[18:-1]

def usunSepartorUrl(url) :
    return re.sub('-', ' ', wytnijUrl(url))

def podajPlec(url) :
    sex = 'kobiety'
    if (re.sub('.*-([^-]*)', '\\1', wytnijUrl(url) )== 'meskie'):
        sex = 'mezczyzni'
    return sex

def plikCSVCategory(url, writer, idCategory) :
    name = re.sub('meskie', 'męskie', usunSepartorUrl(url))
    plec = podajPlec(url)
    webUrl = wytnijUrl(url)
    writer.writerow([idCategory, 1, name, plec, 0, name, name, name, webUrl])

def plikCSVProdukty(url, i, writer, IdPrduct, produkt) :
    cp = Product()
    kategoria = re.sub('meskie', 'męskie', usunSepartorUrl(url) )
    nazwaImg = re.sub('-', '', wytnijUrl(url))
    urlImg = cp.pathImg + str(nazwaImg) + str(i + 1) + '.jpg'
    opis = produkt[i].get('productDescription')
    name = produkt[i].get('name')
    cenaBrutto = re.sub('(zł)', '', re.sub(',', '.', produkt[i].get('oldPrice')))
    newcena = re.sub('(zł)', '', re.sub(',', '.', produkt[i].get('newPrice')))
    wartoscRabatu = round(float(cenaBrutto) - float(newcena), 2)
    urlWeb = wytnijUrl(url) + '-' + str(IdPrduct)
    sizes = ','.join(produkt[i].get('sizes'))
    #                     (['ID', 'Aktywny (0 lub 1)', 'Nazwa', 'Kategorie (x,y,z...)',
    #                     'Cena zawiera podatek. (brutto)', 'ID reguły podatku', 'W sprzedaży (0 lub 1)',
    #                     'Wartość rabatu', 'Cena z podatkiem', 'Ilość', 'Meta-tytuł', 'Słowa kluczowe meta',
    #                     'Opis meta', 'Przepisany URL', 'Adresy URL zdjęcia (x,y,z...)', 'Opis'])
    writer.writerow(
        [IdPrduct, cp.aktywny, name, kategoria, cp.isPodatek, cp.regulaPodatku, cp.wSprzedazy, wartoscRabatu, cenaBrutto, ilosc,
        kategoria, kategoria, name, urlWeb, urlImg, opis])

def plikCSVCombinations(i, writer, IdPrduct, produkt):
    ac = Atribut()
    sizes = produkt[i].get('sizes')
    for j in range(len(sizes)):
        writer.writerow([IdPrduct, ac.nazwa + ac.typ + ac.pozycja, str(sizes[j] + ac.pozycja), ilosc])

def forProdukt(url, writer, idCategory, categoria, csvRodzajPliku) :
    produkt = categoria['processedProducts']
    for i in range(len(produkt)):
        if (csvRodzajPliku == 1 ):
            plikCSVProdukty(url, i, writer, idCategory, produkt)
        if(csvRodzajPliku == 2) :
            plikCSVCombinations(i, writer, idCategory, produkt)
        idCategory += 1
        
def forCategory(writer, jsonList, idCategory, csvRodzajPliku):
    for categoria in jsonList:
        url = categoria['category']
        if(csvRodzajPliku == 0) :
            plikCSVCategory(url, writer, idCategory)
        if(csvRodzajPliku == 1 or csvRodzajPliku == 2) :
            forProdukt(url, writer, idCategory, categoria, csvRodzajPliku)
        idCategory += 1

#def openJson() :
#    with open('json_data.json') as jsonfile:
#        return  json.load(jsonfile)

#def openCSV(nameCSV) :
#    with open(nameCSV,'w', newline='') as categoria_csv:
#        return csv.writer(categoria_csv, delimiter=';')


def createCSVCategory(jsonList) :
    with open('jcategoria.csv','w', newline='', encoding='utf-8') as categoria_csv:
        writer =  csv.writer(categoria_csv, delimiter=';')
        writer.writerow(['Category ID',	'Active (0/1)',	'Name', 'Parent category', 'Root category (0/1)', 'Meta title', 'Meta keywords', 'Meta description', 'URL rewritten'])
        writer.writerow([10, 1, 'kobiety', '', 0, 'odzież damska', 'odzież damska', 'odzież damska', 'kobiety'])
        writer.writerow([11, 1, 'mężczyźni', '', 0, 'odzież męska', 'odzież męska', 'odzież męska', 'mezczyzni'])
        idCategory=12
        csvRodzajPliku = 0
        forCategory(writer, jsonList, idCategory, csvRodzajPliku)

def createCSVProduct(jsonList) :
    with open('jproduct.csv', 'w', newline='', encoding='utf-8') as product_csv:
        writer = csv.writer(product_csv, delimiter=';')
        writer.writerow(['ID', 'Aktywny (0 lub 1)', 'Nazwa', 'Kategorie (x,y,z...)',
                         'Cena zawiera podatek. (brutto)', 'ID reguły podatku', 'W sprzedaży (0 lub 1)',
                         'Wartość rabatu', 'Cena z podatkiem', 'Ilość', 'Meta-tytuł', 'Słowa kluczowe meta',
                         'Opis meta', 'Przepisany URL', 'Adresy URL zdjęcia (x,y,z...)', 'Opis'])
        IdPrduct = 1
        csvRodzajPliku = 1
        forCategory(writer, jsonList, IdPrduct, csvRodzajPliku)

def createCSVCombinations(jsonList) :
    with open('jcombinations.csv', 'w', newline='', encoding='utf-8') as combinations_import:
        writer = csv.writer(combinations_import, delimiter=';')
        writer.writerow(['IdentyfikatorProduktu(ID)', 'Atrybut(Nazwa: Typ:Pozycja) *', 'Wartość(Wartość: Pozycja) *',
                         'Ilość'])
        IdPrduct = 1
        csvRodzajPliku = 2
        forCategory(writer, jsonList, IdPrduct, csvRodzajPliku)

#jsonList = openJson()
with open('json_data.json',  'r', encoding='utf-8') as jsonfile:
    js = json.load(jsonfile)
createCSVCategory(js)
createCSVProduct(js)
createCSVCombinations(js)