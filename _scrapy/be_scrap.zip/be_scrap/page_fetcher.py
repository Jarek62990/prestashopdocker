import time
from bs4 import BeautifulSoup
from selenium import webdriver


class BrowserWrapper:
    def __init__(self):
        options = self.getOptions()
        self.browser = webdriver.Chrome(options=options)

    def openPage(self, url):
        self.browser.get(url)

    def closePage(self):
        self.browser.quit()

    def scrollTo(self, height):
        self.browser.execute_script("window.scrollTo(0, {})".format(height))

    def getPageHeight(self):
        return self.browser.execute_script("return document.body.scrollHeight")

    def getPageHtml(self):
        return self.browser.page_source

    def getOptions(self):
        options = webdriver.ChromeOptions()
        options.add_argument('headless')
        return options

    def slowlyScrollToPageEnd(self):
        currentScroll = 0
        pageHeight = self.getPageHeight()
        while(currentScroll <= pageHeight):
            self.scrollTo(currentScroll)
            currentScroll += 400
            time.sleep(0.5)


def getWholePageContent(url, withSlowlyScrollingToEnd = True):
    browserWrapper = BrowserWrapper()
    browserWrapper.openPage(url)

    if (withSlowlyScrollingToEnd):
        browserWrapper.slowlyScrollToPageEnd()

    html = browserWrapper.getPageHtml()
    browserWrapper.closePage()
    return BeautifulSoup(html, features="html.parser")