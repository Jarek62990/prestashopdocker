DOMAIN = "https://ozonee.pl/"
CATEGORIES_URL = [
    "kurtki-zimowe-meskie/",
    "kurtki-zimowe-damskie/",
    "bluzy-meskie/",
    "bluzy-damskie/",
    "spodnie-meskie/",
    "spodnie-damskie/",
    "spodenki-meskie/",
    "spodenki-damskie/",
]